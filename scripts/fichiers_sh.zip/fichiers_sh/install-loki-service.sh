#!/bin/bash

# === Création du fichier systemd pour Loki ===
cat << 'EOF' | sudo tee /etc/systemd/system/loki.service > /dev/null
[Unit]
Description=Grafana Loki Service
After=network.target

[Service]
ExecStart=/opt/loki-bin -config.file=/etc/loki/loki-config.yml
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
EOF

# === Création du fichier systemd pour Promtail ===
cat << 'EOF' | sudo tee /etc/systemd/system/promtail.service > /dev/null
[Unit]
Description=Grafana Promtail Service
After=network.target

[Service]
ExecStart=/opt/promtail -config.file=/etc/promtail/promtail-config.yml
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
EOF

# === Rechargement du démon systemd ===
sudo systemctl daemon-reexec
sudo systemctl daemon-reload

# === Activation des services au démarrage ===
sudo systemctl enable loki.service
sudo systemctl enable promtail.service

# === Démarrage immédiat des services ===
sudo systemctl start loki.service
sudo systemctl start promtail.service

# === Vérification de l’état des services ===
sudo systemctl status loki.service --no-pager
sudo systemctl status promtail.service --no-pager
