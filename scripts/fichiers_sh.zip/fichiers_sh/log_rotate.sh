#!/bin/bash
# Script : log_rotate.sh
# Rôle : Archive les logs JMeter, Fail2Ban, Suricata, Wazuh

# Définir les chemins
DATE=$(date +%F_%H-%M-%S)
ARCHIVE_DIR="/home/ubuntu/logs_archive/$DATE"
mkdir -p "$ARCHIVE_DIR"

# JMeter
cp /home/ubuntu/tests/results.jtl "$ARCHIVE_DIR/results_$DATE.jtl" 2>/dev/null

# Logs Fail2Ban
cp /var/log/fail2ban.log "$ARCHIVE_DIR/fail2ban_$DATE.log" 2>/dev/null

# Logs Suricata
cp /var/log/suricata/eve.json "$ARCHIVE_DIR/suricata_eve_$DATE.json" 2>/dev/null

# Logs Wazuh
cp /var/ossec/logs/ossec.log "$ARCHIVE_DIR/wazuh_ossec_$DATE.log" 2>/dev/null

# Résultat
echo "✅ Logs archivés dans $ARCHIVE_DIR"
