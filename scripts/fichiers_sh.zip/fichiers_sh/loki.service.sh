sudo tee /etc/systemd/system/loki.service > /dev/null <<EOF
[Unit]
Description=Grafana Loki Service
After=network.target

[Service]
ExecStart=/opt/loki-bin -config.file=/etc/loki/loki-config.yml
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable loki.service
sudo systemctl start loki.service
sudo systemctl status loki.service
