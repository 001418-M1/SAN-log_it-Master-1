#!/bin/bash

# Redémarrer les services
systemctl restart suricata
systemctl restart fail2ban
systemctl restart wazuh-agent

# Lancer un test de charge JMeter
cd /home/user/apache-jmeter/bin
./jmeter -n -t /home/user/tests/test_jitsi.jmx -l /home/user/tests/results.jtl

# Surveillance en temps réel
tail -f /var/log/fail2ban.log /var/log/suricata/eve.json /var/ossec/logs/ossec.log
