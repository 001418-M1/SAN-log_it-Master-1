#!/bin/bash

sudo systemctl restart suricata
sudo systemctl restart fail2ban
sudo systemctl restart wazuh-agent
