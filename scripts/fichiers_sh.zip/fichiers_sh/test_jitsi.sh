#!/bin/bash
# test_jmeter.sh

# Lancer les services de sécurité
systemctl restart suricata
systemctl restart fail2ban
systemctl restart wazuh-agent

# Lancer le test
JMETER_HOME=/home/user/apache-jmeter
$JMETER_HOME/bin/jmeter -n -t /home/user/tests/test_jitsi.jmx -l /home/user/tests/results.jtl

# Surveillance en parallèle
echo "Monitoring en cours - Ctrl+C pour quitter"
tail -f /var/log/fail2ban.log /var/log/suricata/eve.json /var/ossec/logs/ossec.log
