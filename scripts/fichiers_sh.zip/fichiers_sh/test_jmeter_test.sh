#!/bin/bash

# Script: test_jmeter.sh
# Lancer Suricata, Fail2Ban, Wazuh Agent et le test de charge JMeter

systemctl restart suricata
systemctl restart fail2ban
systemctl restart wazuh-agent

JMETER_HOME=/home/user/apache-jmeter
TEST_PLAN=/home/user/tests/test_jitsi.jmx
LOG_PATH=/home/user/tests/results.jtl

# Lancer le test
$JMETER_HOME/bin/jmeter -n -t "$TEST_PLAN" -l "$LOG_PATH"

# Lancer la surveillance
sudo tail -f /var/log/fail2ban.log /var/log/suricata/eve.json /var/ossec/logs/ossec.log
