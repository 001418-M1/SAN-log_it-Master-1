#!/bin/bash

banned=$(sudo fail2ban-client status sshd | grep 'Currently banned' | awk '{print $NF}')
failed=$(sudo fail2ban-client status sshd | grep 'Currently failed' | awk '{print $NF}')

echo "IP currently banned: $banned"
echo "Failed attempts: $failed"

if [ "$banned" -gt 0 ] || [ "$failed" -gt 10 ]; then
  echo "⚠️  Alerte : Activité suspecte détectée."
  # Extension future : webhook / n8n
fi
