#!/bin/bash
for i in {1..20}; do
    user="fakeuser$RANDOM"
    ssh -o StrictHostKeyChecking=no -o ConnectTimeout=2 $user@localhost echo "Test" 2>/dev/null
    sleep $((RANDOM % 5 + 1)) # pause 1 à 5 secondes
done
