#!/bin/bash

# Script : acl_cleanup.sh
# Objet  : Révoquer les ACL attribuées à l'utilisateur 'jmeter' sur les fichiers critiques

USER=jmeter

echo "🚨 Révocation des ACL pour l'utilisateur '$USER'"

FILES=(
  "/var/log/nginx/access.log"
  "/var/log/nginx/error.log"
  "/var/log/fail2ban.log"
  "/var/log/suricata/eve.json"
  "/var/ossec/logs/ossec.log"
  "/var/log/loki.log"
)

for FILE in "${FILES[@]}"; do
  if [ -f "$FILE" ]; then
    echo "🧹 Suppression ACL sur $FILE"
    setfacl -x u:$USER $FILE
  else
    echo "⚠️ Fichier non trouvé : $FILE"
  fi
done

if [ -d "/opt/loki" ]; then
  echo "🧹 Suppression récursive ACL sur /opt/loki"
  setfacl -R -x u:$USER /opt/loki
fi

echo "✅ Révocation des ACL terminée."
