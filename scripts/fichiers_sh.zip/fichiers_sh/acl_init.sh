#!/bin/bash

# Script : acl_init.sh
# Objet  : Appliquer des ACL spécifiques pour l'utilisateur 'jmeter' sur les fichiers critiques de logs

USER=jmeter

# Vérification que l'utilisateur existe
if ! id "$USER" &>/dev/null; then
  echo "Erreur : l'utilisateur '$USER' n'existe pas."
  exit 1
fi

echo "✅ Application des ACL pour l'utilisateur '$USER'"

# Liste des fichiers à sécuriser
FILES=(
  "/var/log/nginx/access.log"
  "/var/log/nginx/error.log"
  "/var/log/fail2ban.log"
  "/var/log/suricata/eve.json"
  "/var/ossec/logs/ossec.log"
  "/var/log/loki.log"
)

for FILE in "${FILES[@]}"; do
  if [ -f "$FILE" ]; then
    echo "⏳ Ajout ACL lecture sur $FILE"
    setfacl -m u:$USER:r $FILE
  else
    echo "⚠️ Fichier manquant : $FILE"
  fi
done

# Exemple : ajouter aussi un répertoire avec accès lecture + exécution
if [ -d "/opt/loki" ]; then
  echo "⏳ Ajout ACL récursive sur /opt/loki"
  setfacl -R -m u:$USER:rx /opt/loki
fi

echo "✅ ACL appliquées avec succès."
