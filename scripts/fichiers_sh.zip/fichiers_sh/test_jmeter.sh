#!/bin/bash

# Script: test_jmeter.sh
# Objectif : Redémarrage des services + test Apache JMeter + suivi des logs

echo "==> Redémarrage des services de sécurité..."
sudo systemctl restart suricata
sudo systemctl restart fail2ban
sudo systemctl restart wazuh-agent

echo "==> Lancement du test Apache JMeter..."
/home/ubuntu/apache-jmeter-5.6.3/bin/jmeter -n -t /home/ubuntu/tests/test_jitsi.jmx -l /home/ubuntu/tests/results.jtl

echo "==> Suivi des logs en temps réel..."
sudo tail -f /var/log/fail2ban.log /var/log/suricata/eve.json /var/ossec/logs/ossec.log
