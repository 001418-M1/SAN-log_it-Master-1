$CacheFile = "$env:TEMP\port_watch_prev.txt"
$TmpFile = "$env:TEMP\port_watch_current.txt"
$LogFile = "$env:TEMP\port_watch.log"

Write-Output "[+] Nettoyage des fichiers de surveillance réseau..."

$files = @($CacheFile, $TmpFile, $LogFile)
foreach ($f in $files) {
    if (Test-Path $f) {
        Remove-Item $f -Force
        Write-Output "  - Supprimé : $f"
    } else {
        Write-Output "  - Absent : $f"
    }
}

Write-Output "[✓] Réinitialisation terminée."
