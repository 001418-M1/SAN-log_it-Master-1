#!/bin/bash

CACHE_FILE="/tmp/port_watch_prev.txt"
TMP_FILE="/tmp/port_watch_current.txt"
LOG_FILE="/tmp/port_watch.log"

echo "[+] Nettoyage des fichiers temporaires de surveillance réseau..."

for f in "$CACHE_FILE" "$TMP_FILE" "$LOG_FILE"; do
    if [ -f "$f" ]; then
        rm -f "$f"
        echo "  - Supprimé : $f"
    else
        echo "  - Absent : $f"
    fi
done

echo "[✓] Réinitialisation terminée."
