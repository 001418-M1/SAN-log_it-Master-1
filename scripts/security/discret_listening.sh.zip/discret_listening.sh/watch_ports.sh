#!/bin/bash

# Liste des ports à surveiller (format décimal)
WATCHED_PORTS=("9145")

# Fichiers de sockets
TCP_FILE="/proc/net/tcp"
UDP_FILE="/proc/net/udp"

# Fichier de cache précédent
CACHE_FILE="/tmp/port_watch_prev.txt"
TMP_FILE="/tmp/port_watch_current.txt"
LOG_FILE="/tmp/port_watch.log"

# Convertit un port décimal en hexadécimal majuscule (ex: 9145 -> 23A1)
function dec_to_hex() {
    printf "%04X" "$1"
}

# Extraction des ports actifs et filtrage
function extract_ports() {
    for f in "$TCP_FILE" "$UDP_FILE"; do
        [ -r "$f" ] || continue
        grep -v "sl" "$f" | while read -r line; do
            local hexport=$(echo "$line" | awk '{print $2}' | cut -d: -f2)
            echo "$hexport"
        done
    done
}

# Génère l’état courant des ports surveillés
function current_state() {
    for port in "${WATCHED_PORTS[@]}"; do
        hex=$(dec_to_hex "$port")
        extract_ports | grep -i "^$hex$" && echo "$port"
    done | sort > "$TMP_FILE"
}

# Comparaison et journalisation
function detect_change() {
    if [ ! -f "$CACHE_FILE" ]; then
        cp "$TMP_FILE" "$CACHE_FILE"
        return
    fi
    diff=$(diff "$CACHE_FILE" "$TMP_FILE")
    if [ -n "$diff" ]; then
        echo "$(date '+%F %T') - Port activity change detected:" >> "$LOG_FILE"
        echo "$diff" >> "$LOG_FILE"
        echo "-----------------------------" >> "$LOG_FILE"
        cp "$TMP_FILE" "$CACHE_FILE"
    fi
}

# Main
current_state
detect_change
