# Ports à surveiller
$WatchedPorts = @(9145)
$LogFile = "$env:TEMP\port_watch.log"
$PreviousStateFile = "$env:TEMP\port_watch_prev.txt"
$CurrentStateFile = "$env:TEMP\port_watch_current.txt"

function Get-CurrentPorts {
    $connections = Get-NetTCPConnection -State Listen
    $watched = @()
    foreach ($p in $WatchedPorts) {
        $match = $connections | Where-Object { $_.LocalPort -eq $p }
        if ($match) {
            $watched += $p
        }
    }
    $watched | Sort-Object | Out-File $CurrentStateFile -Encoding ASCII
}

function Compare-States {
    if (-not (Test-Path $PreviousStateFile)) {
        Copy-Item $CurrentStateFile $PreviousStateFile
        return
    }
    $diff = Compare-Object -ReferenceObject (Get-Content $PreviousStateFile) -DifferenceObject (Get-Content $CurrentStateFile)
    if ($diff) {
        Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - Changement détecté :"
        $diff | Format-Table -AutoSize | Out-String | Add-Content $LogFile
        Add-Content -Path $LogFile -Value "-----------------------------`n"
        Copy-Item $CurrentStateFile $PreviousStateFile
    }
}

# Main
Get-CurrentPorts
Compare-States
